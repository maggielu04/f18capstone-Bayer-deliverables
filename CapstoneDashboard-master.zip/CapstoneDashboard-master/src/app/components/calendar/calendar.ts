/**
 * Created by mohma on 7/26/2017.
 */
export interface Calendar{
  color:string;
  label:string;
  icon:string;
  font:string;
  id:string;
  click:any;
}
