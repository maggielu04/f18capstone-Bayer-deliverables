/**
 * Created by mohma on 7/26/2017.
 */
export interface StatsCard{
  color:string;
  data:number;
  label:string;
  icon:string;
}
