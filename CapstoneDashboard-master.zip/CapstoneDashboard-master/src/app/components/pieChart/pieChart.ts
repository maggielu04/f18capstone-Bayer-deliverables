/**
 * Created by mohma on 7/26/2017.
 */
export interface PieChart{
  color:string;
  current:number;
  max:number;
  label:string;
}
