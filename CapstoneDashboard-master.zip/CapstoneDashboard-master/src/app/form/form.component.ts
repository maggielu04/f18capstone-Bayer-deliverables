/**
 * Created by mohma on 7/26/2017.
 */
import { Component } from '@angular/core';

@Component({
  templateUrl: './form.component.html',
  selector:'formPage'
})
export class FormComponent {

  constructor() {
  }
}


