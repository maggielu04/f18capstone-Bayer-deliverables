/**
 * Created by mohma on 7/26/2017.
 */
import {Injectable} from '@angular/core';
@Injectable()
export class DashboardService {

  constructor() {
  }
}
