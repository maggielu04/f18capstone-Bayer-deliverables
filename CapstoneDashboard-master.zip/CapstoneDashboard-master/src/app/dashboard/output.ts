export class Output {
   topic: string;
   keywords: string;
   authors: string;
   constructor() { 
   }
}