/**
 * Created by mohma on 7/5/2017.
 */
import {Injectable} from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class LoginService {

  constructor( private http: Http) {
  }

  authenticate(email,password) {


  }

}
